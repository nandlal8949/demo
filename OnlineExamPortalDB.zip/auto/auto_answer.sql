-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: auto
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `answer` (
  `answer_id` int NOT NULL AUTO_INCREMENT,
  `answer_text` varchar(260) DEFAULT NULL,
  `question_id` int DEFAULT NULL,
  PRIMARY KEY (`answer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answer`
--

LOCK TABLES `answer` WRITE;
/*!40000 ALTER TABLE `answer` DISABLE KEYS */;
INSERT INTO `answer` VALUES (5,'False',2),(6,'True',2),(7,'echo(\"Hello World\");',1),(8,'Console.WriteLine(\"Hello World\");',1),(9,'System.out.println(\"Hello World\");',1),(10,'print (\"Hello World\");',1),(11,'/* This is a comment',3),(12,'// This is a comment',3),(13,'# This is a comment',3),(14,'myString',4),(15,'String',4),(16,'string',4),(17,'Txt',4),(18,'int x = 5;',5),(19,'num x = 5',5),(20,'float x = 5;',5),(21,'x = 5;',5),(22,'x = 2.8f;',6),(23,'byte x = 2.8f',6),(24,'float x = 2.8f;',6),(25,'int x = 2.8f;',6),(26,'getLength()',7),(27,'size();',7),(28,'fullSize();',7),(29,'len()',7),(30,'length()',7),(31,'The & sign',8),(32,'The * sign',8),(33,'The + sign',8),(34,'True',9),(35,'False',9),(36,'toUpperCase()',10),(37,'upperCase()',10),(38,'touppercase()',10),(39,'tuc()',10),(40,'toUpCase()',10),(41,'toUCase()',10),(42,'==',11),(43,'<>',11),(44,'=',11),(45,'><',11),(46,'[]',12),(47,'()',12),(48,'[{}]',12),(49,'[[]]',12),(50,'{}',12),(51,'0',13),(52,'-1',13),(53,'1',13),(54,'methodName()',14),(55,'methodName.',14),(56,'methodName[]',14),(57,'(methodName)',14),(58,'methodName();',15),(59,'methodName;',15),(60,'(methodName);',15),(61,'methodName[];',15),(62,'class',16),(63,'MyClass',16),(64,'className',16),(65,'class()',16),(66,'MyClass myObj = new MyClass();',17),(67,'class myObj = new MyClass();',17),(68,'class MyClass = new myObj();',17),(69,'new myObj = MyClass();',17),(70,'False',18),(71,'True',18),(72,'Math.max(x,y)',19),(73,'Math.maxNum(x,y)',19),(74,'Math.maximum(x,y)',19),(75,'Math.largest(x,y)',19),(76,'*',20),(77,'#',20),(78,'$',20),(79,'%',20),(80,'**',20),(81,'@',20),(82,'~',20),(83,'lib',21),(84,'lib',21),(85,'import',21),(86,'package',21),(87,'if x > y:',22),(88,'if x > y then:',22),(89,'if x > y:',22),(90,'while x > y {',23),(91,'while x > y:',23),(92,'x > y while {',23),(93,'while (x > y)',23),(94,'return',24),(95,'break',24),(96,'void',24),(97,'continue',24),(98,'get',24),(99,'break',25),(100,'stop',25),(101,'exit',25),(102,'return',25),(107,'Hellow',26),(108,'Throws an exception',26),(109,'None of these',26),(110,'Compilation error',26),(111,'true',27),(112,'0',27),(113,'1',27),(114,'false',27),(115,'Display Error Message',27),(116,'false true',28),(117,'true true',28),(118,'false true',28),(119,'false false',28),(120,'false',29),(121,'0',29),(122,'Compile Error',29),(123,'true',29),(124,'Throw Exception',29),(125,'bc',31),(126,'bcd',31),(127,'abc',31),(128,'abcd',31),(129,'None of these',31),(130,'true',32),(131,'-1',32),(132,'0',32),(133,'false',32),(134,'onetwo',33),(135,'one',33),(136,'None of these',33),(137,'twoone',33),(138,'two',33),(139,'Compilation Error',34),(140,'9.0 9.0',34),(141,'9 9',34),(142,'None of these',34),(143,'I am a Person',35),(144,'I am a Person I am a Student',35),(145,'I am a Student I am a Person',35),(146,'I am a Student',35),(147,'Class One method1',36),(148,'Nothing will be printed',36),(149,'Class Two method1',36),(150,'Compilation Error',36),(151,'Will not compile.',37),(152,'Will compile and run printing out 25',37),(153,'Will compile and run printing out 20',37),(154,'Runtime error',37),(155,'weakly typed',38),(156,'moderate typed',38),(157,'None of these',38),(158,'strongly typed',38),(159,'signed',39),(160,'unsigned',39),(161,'Both of the above',39),(162,'None of these',39),(163,'Set',47),(164,'List',47),(165,'Group',47),(166,'Collection',47),(167,'java.lang',48),(168,'java.awt',48),(169,'java.util',48),(170,'java.net',48),(171,'java.collection',48),(172,'clear()',49),(173,'reset()',49),(174,'delete()',49),(175,'refresh()',49),(176,'compare',50),(177,'toCompare',50),(178,'compareWith',50),(179,'compareTo',50),(180,'h6',51),(181,'heading',51),(182,'h1',51),(183,'head',51),(184,'table, thead, tr, td',52),(185,'colspan, table, tr',52),(186,'table, tt, tr, td',52),(187,'none of the mentioned',52),(188,'width=80',53),(189,'WIDTH=”80″',53),(190,'WIDTH=80',53),(191,'width=”80″',53),(192,'make that specific paragraph red.',54),(193,'error',54),(194,'nothing happens',54),(195,'none of the mentioned',54),(196,'inside an HTML element',55),(197,'inside the section of an HTML page',55),(198,'in an external CSS file',55),(199,'all of the mentioned',55),(200,'align',56),(201,'float',56),(202,'position',56),(203,'padding',56),(204,'id',57),(205,'class',57),(206,'tag',57),(207,'all of the mentioned',57),(208,'all of the mentioned',58),(209,'title and head',58),(210,'head',58),(211,'head and body',58),(212,'ext',59),(213,'script',59),(214,'link',59),(215,'src',59),(216,'Error',60),(217,'5',60),(218,'10',60),(219,'None',60),(220,'1',60);
/*!40000 ALTER TABLE `answer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-30 17:32:03
